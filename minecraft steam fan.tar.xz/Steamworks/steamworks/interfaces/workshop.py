from ctypes import *
from enum import Enum

import steamworks.util 		as util
from steamworks.enums 		import *
from steamworks.structs 	import *
from steamworks.exceptions 	import *


class SteamWorkshop(object):
    _CreateItemResult_t 		= CFUNCTYPE(None, CreateItemResult_t)
    _SubmitItemUpdateResult_t 	= CFUNCTYPE(None, SubmitItemUpdateResult_t)
    _ItemInstalled_t 			= CFUNCTYPE(None, ItemInstalled_t)
    _GetAppDependenciesResult_t = CFUNCTYPE(None, GetAppDependenciesResult)
    _RemoteStorageSubscribePublishedFileResult_t 	= CFUNCTYPE(None, SubscriptionResult)
    _RemoteStorageUnsubscribePublishedFileResult_t 	= CFUNCTYPE(None, SubscriptionResult)
    _SteamUGCQueryCompleted_t = CFUNCTYPE(None, SteamUGCQueryCompleted_t)
    _GetAppDependenciesResult_t = CFUNCTYPE(None, GetAppDependenciesResult_t)
    _DownloadItemResult_t = CFUNCTYPE(None, DownloadItemResult_t)
    _AddUGCDependencyResult_t = CFUNCTYPE(None, AddUGCDependencyResult_t)
    _RemoveUGCDependencyResult_t = CFUNCTYPE(None, RemoveUGCDependencyResult_t)
    _AddAppDependencyResult_t = CFUNCTYPE(None, AddAppDependencyResult_t)
    _RemoveAppDependencyResult_t = CFUNCTYPE(None, RemoveAppDependencyResult_t)

    _CreateItemResult			= None
    _SubmitItemUpdateResult 	= None
    _ItemInstalled 				= None
    _GetAppDependenciesResult = None
    _RemoteStorageSubscribePublishedFileResult 	= None
    _RemoteStorageUnsubscribePublishedFileResult = None
    _SteamUGCQueryCompleted = None
    _GetAppDependenciesResult = None
    _DownloadItemResult = None
    _AddUGCDependencyResult = None
    _RemoveUGCDependencyResult = None
    _AddAppDependencyResult = None
    _RemoveAppDependencyResult = None


    def __init__(self, steam: object):
        self.steam = steam
        if not self.steam.loaded():
            raise SteamNotLoadedException('STEAMWORKS not yet loaded')

        self.GetNumSubscribedItems() # This fixes #58


    def SetItemCreatedCallback(self, callback: object) -> bool:
        """Set callback for item created

        :param callback: callable
        :return: bool
        """
        self._CreateItemResult = SteamWorkshop._CreateItemResult_t(callback)
        self.steam.Workshop_SetItemCreatedCallback(self._CreateItemResult)
        return True


    def SetItemUpdatedCallback(self, callback: object) -> bool:
        """Set callback for item updated

        :param callback: callable
        :return: bool
        """
        self._SubmitItemUpdateResult = self._SubmitItemUpdateResult_t(callback)
        self.steam.Workshop_SetItemUpdatedCallback(self._SubmitItemUpdateResult)
        return True


    def SetItemInstalledCallback(self, callback: object) -> bool:
        """Set callback for item installed

        :param callback: callable
        :return: bool
        """
        self._ItemInstalled = self._ItemInstalled_t(callback)
        self.steam.Workshop_SetItemInstalledCallback(self._ItemInstalled)
        return True


    def ClearItemInstalledCallback(self) -> None:
        """Clear item installed callback

        :return: None
        """
        self._ItemInstalled = None
        self.steam.Workshop_ClearItemInstalledCallback()


    def SetGetAppDependenciesResultCallback(self, callback: object) -> bool:
        """Set callback for item GetAppDependencies

        :param callback: callable
        :return: bool
        """
        self._GetAppDependenciesResult = self._GetAppDependenciesResult_t(callback)
        self.steam.Workshop_SetGetAppDependenciesResultCallback(self._GetAppDependenciesResult)
        return True


    def SetItemSubscribedCallback(self, callback: object) -> bool:
        """Set callback for item subscribed

        :param callback: callable
        :return: bool
        """
        self._RemoteStorageSubscribePublishedFileResult = self._RemoteStorageSubscribePublishedFileResult_t(callback)
        self.steam.Workshop_SetItemSubscribedCallback(self._RemoteStorageSubscribePublishedFileResult)
        return True


    def SetItemUnsubscribedCallback(self, callback: object) -> bool:
        """Set callback for item unsubscribed

        :param callback: callable
        :return: bool
        """
        self._RemoteStorageUnsubscribePublishedFileResult = self._RemoteStorageUnsubscribePublishedFileResult_t(callback)
        self.steam.Workshop_SetItemUnsubscribedCallback(self._RemoteStorageUnsubscribePublishedFileResult)
        return True


    def CreateItem(self, app_id: int, filetype: EWorkshopFileType, callback: object = None, override_callback: bool = False) -> None:
        """Creates a new workshop item with no content attached yet

        :param app_id: int
        :param filetype: EWorkshopFileType
        :param callback: callable
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetItemCreatedCallback(callback)

        elif callback and not self._CreateItemResult:
            self.SetItemCreatedCallback(callback)

        self.steam.Workshop_CreateItem(app_id, filetype.value)


    def GetAppDependencies(self, published_file_id: int, callback: object = None, override_callback: bool = False) -> None:
        """Get a list of AppID dependencies from a UGC (Workshop) item

        :param published_file_id: int
        :param callback: callable
        :param override_callback: bool
        :return:
        """
        if override_callback:
            self.SetGetAppDependenciesResultCallback(callback)

        elif callback and not self._GetAppDependenciesResult:
            self.SetGetAppDependenciesResultCallback(callback)

        if self._GetAppDependenciesResult is None:
            raise SetupRequired('Call `SetGetAppDependenciesResultCallback` first or supply a `callback`')

        self.steam.Workshop_GetAppDependencies(published_file_id)


    def SubscribeItem(self, published_file_id: int, callback: object = None, override_callback: bool = False) -> None:
        """ Subscribe to a UGC (Workshp) item

        :param published_file_id: int
        :param callback: callable
        :param override_callback: bool
        :return:
        """
        if override_callback:
            self.SetItemSubscribedCallback(callback)

        elif callback and not self._RemoteStorageSubscribePublishedFileResult:
            self.SetItemSubscribedCallback(callback)

        if self._RemoteStorageSubscribePublishedFileResult is None:
            raise SetupRequired('Call `SetItemSubscribedCallback` first or supply a `callback`')

        self.steam.Workshop_SubscribeItem(published_file_id)


    def UnsubscribeItem(self, published_file_id: int, callback: object = None, override_callback: bool = False) -> None:
        """ Unsubscribe to a UGC (Workshp) item

        :param published_file_id: int
        :param callback: callable
        :param override_callback: bool
        :return:
        """
        if override_callback:
            self.SetItemUnsubscribedCallback(callback)

        elif callback and not self._RemoteStorageUnsubscribePublishedFileResult:
            self.SetItemUnsubscribedCallback(callback)

        if self._RemoteStorageUnsubscribePublishedFileResult is None:
            raise SetupRequired('Call `SetItemUnsubscribedCallback` first or supply a `callback`')

        self.steam.Workshop_UnsubscribeItem(published_file_id)


    def StartItemUpdate(self, app_id: int, published_file_id: int) -> int:
        """ Start the item update process and receive an update handle

        :param app_id: int
        :param published_file_id: int
        :return: int
        """
        return self.steam.Workshop_StartItemUpdate(app_id, c_uint64(published_file_id))


    def SetItemTitle(self, update_handle: int, title: str) -> bool:
        """Set the title of a Workshop item

        :param update_handle: int
        :param title: str
        :return: bool
        """
        if len(title) > 128:
            raise AttributeError('title exceeds 128 characters')

        return self.steam.Workshop_SetItemTitle(update_handle, title.encode())


    def SetItemDescription(self, update_handle: int, description: str) -> bool:
        """Set the description of a Workshop item

        :param update_handle: int
        :param description: str
        :return: bool
        """
        if len(description) > 8000:
            raise AttributeError('description exceeds 8000 characters')

        return self.steam.Workshop_SetItemDescription(update_handle, description.encode())


    def SetItemTags(self, update_handle: int, tags: list) -> bool:
        """Sets which tags apply to the Workshop item

        :param update_handle: int
        :param tags: string list
        :return: bool
        """

        pointer_storage = (c_char_p * len(tags))()
        for index, tag in enumerate(tags):
            pointer_storage[index] = tag.encode()

        return self.steam.Workshop_SetItemTags(update_handle, pointer_storage, len(tags))


    def SetItemVisibility(self, update_handle: int, vis: ERemoteStoragePublishedFileVisibility) -> bool:
        """Sets which users can see the Workshop item

        :param update_handle: int
        :param vis: ERemoteStoragePublishedFileVisibility
        :return: bool
        """

        return self.steam.Workshop_SetItemVisibility(update_handle, vis.value)


    def SetItemContent(self, update_handle: int, content_directory: str) -> bool:
        """ Set the directory containing the content you wish to upload to Workshop

        :param update_handle: int
        :param content_directory: str
        :return: bool
        """
        return self.steam.Workshop_SetItemContent(update_handle, content_directory.encode())


    def SetItemPreview(self, update_handle: int, preview_image: str) -> bool:
        """Set the preview image of the Workshop item.

        :param update_handle: int
        :param preview_image: str (absolute path to a file on disk)
        :return: bool
        """
        return self.steam.Workshop_SetItemPreview(update_handle, preview_image.encode())


    def SubmitItemUpdate(self, update_handle: int, change_note: str, callback: object = None, \
                         override_callback: bool = False) -> None:
        """Submit the item update with the given handle to Steam

        :param update_handle: int
        :param change_note: str
        :param callback: callable
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetItemUpdatedCallback(callback)

        elif callback and not self._SubmitItemUpdateResult:
            self.SetItemUpdatedCallback(callback)

        if change_note:
            change_note = change_note.encode()
        else:
            change_note = None

        self.steam.Workshop_SubmitItemUpdate(update_handle, change_note)


    def GetItemUpdateProgress(self, update_handle: int) -> dict:
        """Get the progress of an item update request

        :param update_handle: int
        :return: dict
        """
        punBytesProcessed = c_uint64()
        punBytesTotal = c_uint64()

        update_status = self.steam.Workshop_GetItemUpdateProgress(
            update_handle,
            pointer(punBytesProcessed),
            pointer(punBytesTotal))

        return {
            'status' : EItemUpdateStatus(update_status),
            'processed' : punBytesProcessed.value,
            'total' : punBytesTotal.value,
            'progress' : ( punBytesProcessed.value / (punBytesTotal.value or 1) )
        }


    def GetNumSubscribedItems(self) -> int:
        """Get the total number of items the user is subscribed to for this game or application

        :return: int
        """
        return self.steam.Workshop_GetNumSubscribedItems()


    def SuspendDownloads(self, paused: bool = True) -> None:
        """Suspend active workshop downloads

        :param paused: bool
        :return: None
        """
        return self.steam.Workshop_SuspendDownloads(paused)


    def GetSubscribedItems(self, max_items: int = 0) -> list:
        """Get a list of published file IDs that the user is subscribed to

        :param max_items: int
        :return:
        """
        if max_items <= 0:
            max_items = self.GetNumSubscribedItems()

        if max_items == 0:
            return []

        published_files_ctype = c_uint64 * max_items
        published_files = published_files_ctype()

        # TODO: We might need to add an exception check here to catch any errors while
        # writing to the 'pvecPublishedFileIds' array.
        actual_item_count = self.steam.Workshop_GetSubscribedItems(published_files, max_items)
        # According to sdk's example, it is possible for numItems to be greater than maxEntries so we crop.
        if actual_item_count > max_items:
            published_files = published_files[:max_items]

        return published_files


    def GetItemState(self, published_file_id: int) -> EItemState:
        """Get the current state of a workshop item

        :param published_file_id: published_file_id
        :return: EItemState
        """
        return EItemState(self.steam.Workshop_GetItemState(published_file_id))


    def GetItemInstallInfo(self, published_file_id: int, max_path_length: int = 1024) -> dict:
        """Get info about an installed item

        :param published_file_id: int
        :param max_path_length: str
        :return: dict
        """
        punSizeOnDisk = pointer(c_uint64(0))
        punTimeStamp = pointer(c_uint32(0))
        pchFolder = create_string_buffer(max_path_length)

        is_installed = self.steam.Workshop_GetItemInstallInfo(
            published_file_id, punSizeOnDisk, pchFolder, max_path_length, punTimeStamp)

        if not is_installed:
            return {}

        return {
            'disk_size' : punSizeOnDisk,
            'folder' : pchFolder.value.decode(),
            'timestamp' : punTimeStamp.contents.value
        }


    def GetItemDownloadInfo(self, published_file_id: int) -> dict:
        """Get download info for a subscribed item

        :param published_file_id: int
        :return:
        """
        punBytesDownloaded = pointer(c_uint64(0))
        punBytesTotal = pointer(c_uint64(0))

        # pBytesTotal will only be valid after the download has started.
        available = self.steam.Workshop_GetItemDownloadInfo(published_file_id, punBytesDownloaded, punBytesTotal)
        if available:
            downloaded = punBytesDownloaded.contents.value
            total = punBytesTotal.contents.value

            return {
                'downloaded' : downloaded,
                'total' : total,
                'progress' : 0.0 if total <= 0 else ( downloaded / total )
            }

        return {}


    def CreateQueryUGCDetailsRequest(self, published_file_ids: list) -> int:
        """Create UGC item details query request

        :param published_file_ids: int list
        :return: int
        """
        published_files_c = (c_uint64 * len(published_file_ids))()
        for index, published_file_id in enumerate(published_file_ids):
            published_files_c[index] = c_uint64(published_file_id)

        return self.steam.Workshop_CreateQueryUGCDetailsRequest(published_files_c, len(published_file_ids))


    def SetQueryUGCRequestCallback(self, callback: object) -> bool:
        """Set callback for UGC query

        :param callback: callable
        :return: bool
        """
        self._SteamUGCQueryCompleted = SteamWorkshop._SteamUGCQueryCompleted_t(callback)
        self.steam.Workshop_SetQueryCompletedCallback(self._SteamUGCQueryCompleted)
        return True


    def SendQueryUGCRequest(self, handle: int, callback: object = None, override_callback: bool = False) -> None:
        """Create UGC item details query request

        :param handle: query handle
        :param callback: callable
        :param override_callback: bool
        :return:
        """
        if override_callback:
            self.SetQueryUGCRequestCallback(callback)

        elif callback and not self._SteamUGCQueryCompleted:
            self.SetQueryUGCRequestCallback(callback)

        if self._SteamUGCQueryCompleted is None:
            raise SetupRequired('Call `SetQueryUGCRequestCallback` first or supply a `callback`')

        self.steam.Workshop_SendQueryUGCRequest(handle)


    def GetQueryUGCResult(self, handle: int, index: int) -> SteamUGCDetails_t:
        """Create UGC item details query request

        :param handle: query handle
        :param index: int
        :return: SteamUGCDetails_t
        """
        details = SteamUGCDetails_t()
        self.steam.Workshop_GetQueryUGCResult(handle, index, byref(details))
        return details


    def SetGetAppDependenciesCallback(self, callback: object) -> bool:
        """Set callback for GetAppDependencies result

        :param callback: callable
        :return: bool
        """
        self._GetAppDependenciesResult = self._GetAppDependenciesResult_t(callback)
        self.steam.Workshop_SetGetAppDependenciesCallback(self._GetAppDependenciesResult)
        return True


    def GetAppDependencies(self, published_file_id: int, callback: object = None,
                           override_callback: bool = False) -> None:
        """Get app dependencies for a workshop item

        Returns a list of app IDs that the workshop item depends on.
        These are "soft" dependencies shown on the Steam Workshop web page.
        The callback may be called multiple times if there are more than 32 dependencies.

        :param published_file_id: int
        :param callback: callable - receives GetAppDependenciesResult_t
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetGetAppDependenciesCallback(callback)

        elif callback and not self._GetAppDependenciesResult:
            self.SetGetAppDependenciesCallback(callback)

        if self._GetAppDependenciesResult is None:
            raise SetupRequired('Call `SetGetAppDependenciesCallback` first or supply a `callback`')

        self.steam.Workshop_GetAppDependencies(published_file_id)


    def DownloadItem(self, published_file_id: int, high_priority: bool = False,
                     callback: object = None, override_callback: bool = False) -> bool:
        """Initiate or prioritize download of a workshop item

        Downloads or updates a workshop item. If high_priority is True, this item will
        be downloaded before any other items. The function returns immediately, and you
        should wait for the callback before accessing the item on disk.

        NOTE: The callback will be triggered for all item downloads regardless of the
        running application, so check the appID in the callback result.

        :param published_file_id: int
        :param high_priority: bool - Set to True to pause other downloads and prioritize this one
        :param callback: callable - receives DownloadItemResult_t when download completes (REQUIRED)
        :param override_callback: bool
        :return: bool - True if download initiated successfully
        """
        # Callback is required - set it up internally
        if callback is None:
            raise ValueError('callback parameter is required for DownloadItem')

        if override_callback or not self._DownloadItemResult:
            self._DownloadItemResult = self._DownloadItemResult_t(callback)
            self.steam.Workshop_SetDownloadItemCallback(self._DownloadItemResult)

        return self.steam.Workshop_DownloadItem(published_file_id, high_priority)


    # ------------------------------------------------------------------
    # Required Items (workshop-to-workshop dependencies)
    # ------------------------------------------------------------------
    def SetAddDependencyResultCallback(self, callback: object) -> bool:
        """Set callback for AddDependency result (AddUGCDependencyResult_t)."""
        self._AddUGCDependencyResult = SteamWorkshop._AddUGCDependencyResult_t(callback)
        self.steam.Workshop_SetAddDependencyResultCallback(self._AddUGCDependencyResult)
        return True


    def AddDependency(self, parent_file_id: int, child_file_id: int,
                      callback: object = None, override_callback: bool = False) -> None:
        """Add ``child_file_id`` as a Required Item of ``parent_file_id``.

        Both must be published Workshop items the calling account owns.
        Asynchronous: the optional ``callback`` receives an
        ``AddUGCDependencyResult_t``. If no callback is supplied the
        call is fire-and-forget (pump ``run_callbacks`` to let it land).

        :param parent_file_id: int  (the item that gains a Required Item)
        :param child_file_id: int   (the item that becomes required)
        :param callback: callable
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetAddDependencyResultCallback(callback)
        elif callback and not self._AddUGCDependencyResult:
            self.SetAddDependencyResultCallback(callback)

        self.steam.Workshop_AddDependency(parent_file_id, child_file_id)


    def SetRemoveDependencyResultCallback(self, callback: object) -> bool:
        """Set callback for RemoveDependency result (RemoveUGCDependencyResult_t)."""
        self._RemoveUGCDependencyResult = SteamWorkshop._RemoveUGCDependencyResult_t(callback)
        self.steam.Workshop_SetRemoveDependencyResultCallback(self._RemoveUGCDependencyResult)
        return True


    def RemoveDependency(self, parent_file_id: int, child_file_id: int,
                         callback: object = None, override_callback: bool = False) -> None:
        """Remove the Required Item link ``child_file_id`` from ``parent_file_id``.

        :param parent_file_id: int
        :param child_file_id: int
        :param callback: callable - receives RemoveUGCDependencyResult_t
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetRemoveDependencyResultCallback(callback)
        elif callback and not self._RemoveUGCDependencyResult:
            self.SetRemoveDependencyResultCallback(callback)

        self.steam.Workshop_RemoveDependency(parent_file_id, child_file_id)


    # ------------------------------------------------------------------
    # App dependencies (item depends on a game/DLC AppID)
    # ------------------------------------------------------------------
    def SetAddAppDependencyResultCallback(self, callback: object) -> bool:
        """Set callback for AddAppDependency result (AddAppDependencyResult_t)."""
        self._AddAppDependencyResult = SteamWorkshop._AddAppDependencyResult_t(callback)
        self.steam.Workshop_SetAddAppDependencyResultCallback(self._AddAppDependencyResult)
        return True


    def AddAppDependency(self, published_file_id: int, app_id: int,
                         callback: object = None, override_callback: bool = False) -> None:
        """Declare that workshop item ``published_file_id`` depends on ``app_id``.

        :param published_file_id: int
        :param app_id: int
        :param callback: callable - receives AddAppDependencyResult_t
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetAddAppDependencyResultCallback(callback)
        elif callback and not self._AddAppDependencyResult:
            self.SetAddAppDependencyResultCallback(callback)

        self.steam.Workshop_AddAppDependency(published_file_id, app_id)


    def SetRemoveAppDependencyResultCallback(self, callback: object) -> bool:
        """Set callback for RemoveAppDependency result (RemoveAppDependencyResult_t)."""
        self._RemoveAppDependencyResult = SteamWorkshop._RemoveAppDependencyResult_t(callback)
        self.steam.Workshop_SetRemoveAppDependencyResultCallback(self._RemoveAppDependencyResult)
        return True


    def RemoveAppDependency(self, published_file_id: int, app_id: int,
                            callback: object = None, override_callback: bool = False) -> None:
        """Remove the app dependency ``app_id`` from ``published_file_id``.

        :param published_file_id: int
        :param app_id: int
        :param callback: callable - receives RemoveAppDependencyResult_t
        :param override_callback: bool
        :return: None
        """
        if override_callback:
            self.SetRemoveAppDependencyResultCallback(callback)
        elif callback and not self._RemoveAppDependencyResult:
            self.SetRemoveAppDependencyResultCallback(callback)

        self.steam.Workshop_RemoveAppDependency(published_file_id, app_id)


    # ------------------------------------------------------------------
    # Synchronous item-update setters (used between Start/SubmitItemUpdate)
    # ------------------------------------------------------------------
    def AddItemKeyValueTag(self, update_handle: int, key: str, value: str) -> bool:
        """Add a key-value metadata tag to the pending item update.

        :param update_handle: int
        :param key: str
        :param value: str
        :return: bool
        """
        return self.steam.Workshop_AddItemKeyValueTag(update_handle, key.encode(), value.encode())


    def RemoveItemKeyValueTags(self, update_handle: int, key: str) -> bool:
        """Remove all key-value tags matching ``key`` from the pending update.

        :param update_handle: int
        :param key: str
        :return: bool
        """
        return self.steam.Workshop_RemoveItemKeyValueTags(update_handle, key.encode())


    def RemoveAllItemKeyValueTags(self, update_handle: int) -> bool:
        """Remove every key-value tag from the pending item update.

        :param update_handle: int
        :return: bool
        """
        return self.steam.Workshop_RemoveAllItemKeyValueTags(update_handle)


    def AddContentDescriptor(self, update_handle: int, descriptor_id: int) -> bool:
        """Tag the item with a mature-content descriptor (EUGCContentDescriptorID).

        :param update_handle: int
        :param descriptor_id: int
        :return: bool
        """
        return self.steam.Workshop_AddContentDescriptor(update_handle, descriptor_id)


    def RemoveContentDescriptor(self, update_handle: int, descriptor_id: int) -> bool:
        """Remove a previously set content descriptor from the item.

        :param update_handle: int
        :param descriptor_id: int
        :return: bool
        """
        return self.steam.Workshop_RemoveContentDescriptor(update_handle, descriptor_id)
