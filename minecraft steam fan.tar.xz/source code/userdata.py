import os
import re
import psutil
import steam
from tkinter import messagebox
import minecraft_launcher_lib as mll


def minecraft_username(name):
    # Кириллица -> латиница
    translit = {
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d",
        "е": "e", "ё": "yo", "ж": "zh", "з": "z", "и": "i",
        "й": "y", "к": "k", "л": "l", "м": "m", "н": "n",
        "о": "o", "п": "p", "р": "r", "с": "s", "т": "t",
        "у": "u", "ф": "f", "х": "kh", "ц": "ts", "ч": "ch",
        "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "",
        "э": "e", "ю": "yu", "я": "ya"
    }

    # Транслитерация
    name = "".join(
        translit.get(char.lower(), char)
        for char in name
    )

    # Пробелы -> _
    name = re.sub(r"\s+", "_", name)

    # Оставляем только A-Z, a-z, 0-9 и _
    name = re.sub(r"[^A-Za-z0-9_]", "", name)

    # Убираем _ с начала и конца
    name = name.strip("_")

    # Максимум 16 символов
    name = name[:16]

    # Если после очистки ничего не осталось
    return name or "MinecraftSteamUser"


# Выделяем доступную RAM
ram = psutil.virtual_memory().available // (1024 ** 3) - 1

if ram < 3:
    messagebox.showerror("Minecraft", "Not enough RAM")
    os._exit(1)

maxram = f"-Xmx{ram}G"
minram = f"-Xms{int(ram // 1.5)}G"

args = [maxram, minram]

settings = {
    "username": minecraft_username(steam.nick),
    "jvmArguments": args
}

folder = os.path.abspath(".minecraft")
os.makedirs(folder, exist_ok=True)

lastver = mll.utils.get_latest_version()["release"]