import minecraft_launcher_lib as mll
import userdata
import subprocess as sub

def run():
    command = mll.command.get_minecraft_command(userdata.lastver, userdata.folder, userdata.settings)
    sub.Popen(command, creationflags=sub.CREATE_NO_WINDOW).wait()