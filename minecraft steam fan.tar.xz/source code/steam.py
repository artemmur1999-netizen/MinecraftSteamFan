import os
import sys
from tkinter import messagebox

steamworks_path = os.path.abspath("Steamworks")
sys.path.append(steamworks_path)
os.add_dll_directory(steamworks_path)
old = os.getcwd()

from steamworks import STEAMWORKS
from steamworks.exceptions import SteamNotRunningException

steamworks = STEAMWORKS()
try:
    steamworks.initialize()
except SteamNotRunningException:
    messagebox.showerror(
        "Steamworks Api", "Steam isn't running, \nplease run Steam and re-open this app."
    )
    os._exit(1)
except Exception as e:
    messagebox.showerror("Steamworks Api", f"Unkown Error happened! Exception:\n{e}")
    os._exit(1)

my_steam_id = steamworks.Users.GetSteamID()

nick_bytes = steamworks.Friends.GetFriendPersonaName(my_steam_id)
nick = nick_bytes.decode('utf-8')