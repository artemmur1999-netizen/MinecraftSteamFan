import threading
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import userdata
import minecraft_launcher_lib as mll
import run

def start():
    # Создаем окно лаунчера
    window = tk.Tk()
    window.title("Starting Minecraft")
    window.geometry("400x250")
    window.resizable(False, False)
    
    # Центрируем окно на экране
    window.eval('tk::PlaceWindow . center')

    # Текст статуса
    label = tk.Label(window, text="Preparing to launch...", font=("Arial", 10))
    label.pack(pady=10)

    # Прогресс-бар
    progress = ttk.Progressbar(window, orient="horizontal", length=350, mode="determinate", maximum=100)
    progress.pack(pady=5)

    # Текстовое поле для логов внутри окна
    log_text = tk.Text(window, height=6, width=47, font=("Consolas", 8))
    log_text.pack(pady=10)
    log_text.config(state=tk.DISABLED) # Исправлено: tk.DISABLED вместо tk.disabled

    def add_log(message):
        """Безопасное добавление лога в текстовое поле из любого потока"""
        print(message) # Дублируем в консоль
        def update():
            log_text.config(state=tk.NORMAL) # Исправлено: tk.NORMAL
            log_text.insert(tk.END, message + "\n")
            log_text.see(tk.END) # Прокрутка вниз
            log_text.config(state=tk.DISABLED) # Исправлено: tk.DISABLED
        window.after(0, update)

    def worker():
        try:
            add_log(f"[INFO] Target version: {userdata.lastver}")
            window.after(0, lambda: label.config(text=f"Installing version {userdata.lastver}..."))
            
            max_steps = 0
            current_step = 0

            def set_status(status: str):
                add_log(f"[STATUS] {status}")
                window.after(0, lambda: label.config(text=status))

            def set_max(maximum: int):
                nonlocal max_steps
                max_steps = maximum
                window.after(0, lambda: progress.config(maximum=maximum))

            def set_progress(value: int):
                nonlocal current_step
                current_step = value
                window.after(0, lambda: progress.config(value=value))

            callback = {
                "setStatus": set_status,
                "setMax": set_max,
                "setProgress": set_progress
            }

            mll.install.install_minecraft_version(userdata.lastver, userdata.folder, callback=callback)
            
            add_log("[INFO] Installation completed successfully!")
            window.after(0, lambda: label.config(text="Starting Minecraft..."))
            window.after(500, window.destroy)
            
            add_log("[INFO] Handing over to run.py...")
            run.run()
            
        except Exception as e:
            add_log(f"[ERROR] {e}")
            window.after(0, window.destroy)
            window.after(0, lambda: messagebox.showerror("Minecraft", f"Unknown error happened, Exception:\n{e}"))

    threading.Thread(target=worker, daemon=True).start()
    
    window.mainloop()

if __name__ == "__main__":
    start()